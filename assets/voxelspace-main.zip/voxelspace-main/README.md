# Voxel Space Engine

This is an extremely naive Voxel Space engine implementation created for [this Youtube video](https://youtu.be/bQBY9BM9g_Y).

<img src="maps/gif/voxelspace.gif" alt="Voxel Space Engine" width="320"/>

For more information, visit:
[https://pikuma.com](https://pikuma.com)

If you have any questions, please drop me a message at <a href="mailto:info@pikuma.com">info@pikuma.com</a>
